create database adbms123;

create table student(
	s_ssn int,
	s_fname varchar(255),
	s_lname varchar(255),
	s_age int,
	s_gender int,
	s_tel_no int,
	s_email varchar(255),
	s_bday int,
	s_address int
);

