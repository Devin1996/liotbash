<?php

$server="localhost";
$uname="root";
$pw="";
$dbname="liot";


?>
<html>
<head></head>

<body>

<form action="StudentRegisterXML.php" method="GET">

Uname <input type="text" name="uno"><br>

<input type="submit">
</form>

</body>




</html>